import json
import re
import urllib.request
import xml.etree.ElementTree as ET
from datetime import datetime, timezone
from email.utils import parsedate_to_datetime
from pathlib import Path
from html import unescape

# Public RSS feeds. RSS usage and republication terms vary by publisher.
FEEDS = [
    ("BBC Türkçe", "Türkiye", "https://feeds.bbci.co.uk/turkce/rss.xml"),
    ("Anadolu Ajansı", "Dünya", "https://www.aa.com.tr/en/rss/default?cat=europe"),
    ("Al Jazeera", "Dünya", "https://www.aljazeera.com/xml/rss/all.xml"),
    ("BBC World", "Dünya", "https://feeds.bbci.co.uk/news/world/rss.xml"),
    ("Google News · Savunma", "Savunma", "https://news.google.com/rss/search?q=defense+OR+military+technology&hl=tr&gl=TR&ceid=TR:tr"),
    ("Google News · Siyaset", "Siyaset", "https://news.google.com/rss/search?q=uluslararas%C4%B1+siyaset+OR+diplomasi&hl=tr&gl=TR&ceid=TR:tr"),
]
OUT = Path("site/news.json")

def clean(text):
    text = re.sub(r"<[^>]+>", " ", text or "")
    return re.sub(r"\s+", " ", unescape(text)).strip()

def parse_date(value):
    if not value:
        return ""
    try:
        dt = parsedate_to_datetime(value)
        return dt.astimezone(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
    except Exception:
        return value[:80]

items, seen = [], set()
for source, category, url in FEEDS:
    try:
        request = urllib.request.Request(url, headers={"User-Agent":"ILTERIS-RSS-Reader/1.0 (headline aggregation)"})
        with urllib.request.urlopen(request, timeout=20) as response:
            raw = response.read(3_000_000)
        root = ET.fromstring(raw)
        for node in root.findall(".//item")[:25]:
            title = clean(node.findtext("title"))
            link = (node.findtext("link") or "").strip()
            desc = clean(node.findtext("description"))
            pub = parse_date(node.findtext("pubDate"))
            key = link or title
            if not title or not link or key in seen:
                continue
            seen.add(key)
            items.append({
                "title": title[:240], "link": link, "summary": desc[:320],
                "source": source, "category": category, "published_at": pub
            })
    except Exception as exc:
        print(f"Feed failed: {source}: {exc}")

items.sort(key=lambda x: x.get("published_at", ""), reverse=True)
payload = {
    "updated_at": datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC"),
    "items": items[:60]
}
OUT.parent.mkdir(parents=True, exist_ok=True)
OUT.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
print(f"Wrote {len(payload['items'])} headline items to {OUT}")
