# İLTERİS — Askerî, Siyasi ve Jeopolitik Haberler

Bu paket, mevcut İLTERİS HTML tasarımını GitHub Pages üzerinden ücretsiz yayımlamaya ve RSS başlıklarını otomatik toplamaya yönelik başlangıç projesidir.

## Neler var?
- `site/index.html`: mobil uyumlu web sitesi
- `site/news.json`: RSS başlıklarının yayınlandığı JSON dosyası
- `fetch_news.py`: RSS akışlarını okur, başlık/özet/kaynak bağlantılarını toplar
- `.github/workflows/refresh-news.yml`: yaklaşık her 30 dakikada bir akışı yeniler

## Telefonda yayımlama adımları
1. GitHub hesabı oluşturun veya hesabınıza giriş yapın.
2. Yeni bir **public repository** oluşturun; örneğin `ilteris`.
3. Bu ZIP'in içeriğini bilgisayardan veya GitHub'ın web arayüzünden deponun köküne yükleyin. `.github/workflows/refresh-news.yml` dosyasının yolunun aynen korunduğundan emin olun.
4. GitHub deposunda **Settings → Pages** bölümüne gidin. Build and deployment kaynağını **Deploy from a branch**, branch'i `main`, klasörü `/site` seçip kaydedin.
5. **Actions** sekmesinden `Refresh ILTERIS RSS headlines` iş akışını açın ve **Run workflow** ile ilk çalışmayı başlatın. Gerekirse Settings → Actions → General bölümünde GitHub Actions'ın etkin olduğundan emin olun.
6. Pages dağıtımı tamamlandığında siteniz `https://KULLANICI-ADIN.github.io/DEPO-ADI/` benzeri bir adreste açılır. Gerçek adresi GitHub Pages ekranı gösterir.

## Önemli sınırlamalar
- Bu paket otomatik olarak internete yüklenmez; GitHub hesabınızda yükleme ve Pages ayarlarını sizin yapmanız gerekir.
- RSS güncellemesi planlanmış olsa da GitHub Actions ve kaynak akışların erişilebilirliği garanti edilmez.
- Akışlar başlık, kısa özet ve kaynak bağlantısı toplar; tam haber metinlerini kopyalamaz. Kaynak sitelerin RSS ve yeniden kullanım şartlarına uyun. Yayına almadan önce her kaynağın koşullarını inceleyin.
- Otomatik toplama, haberin doğrulandığı anlamına gelmez. Özellikle askerî çatışma haberlerinde yayımlamadan önce en az iki güvenilir kaynaktan kontrol edin; iddiaları açıkça atfedin ve düzeltme politikasını yayımlayın.
- Bu ilk sürümün abonelik formu gerçek e-posta toplamaz. Yönetim paneli ve haber yayımlama sistemi dahil değildir.
- Kaynaklar arasında BBC Türkçe, Anadolu Ajansı İngilizce Avrupa akışı, Al Jazeera, BBC World ve Google News konu aramaları bulunur. Kategori etiketleri yaklaşık sınıflandırmadır.
